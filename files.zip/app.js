document.addEventListener('DOMContentLoaded', () => {
    console.log('Telecommunication website is loaded');
});